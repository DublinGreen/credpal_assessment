<?php

define("API_HOST", 'localhost:8000');
